/*
 * Copyright 2004-2006 Sean Owen
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.planetj.servlet.filter.compression;

import com.mockrunner.mock.web.MockHttpServletRequest;
import com.mockrunner.mock.web.MockServletContext;
import com.mockrunner.mock.web.WebMockObjectFactory;
import com.mockrunner.servlet.ServletTestModule;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

/**
 * Can be used to generate load on {@link CompressingFilter}.
 *
 * @author Sean Owen
 */
public final class LoadRunner {

	private LoadRunner() {
		// do nothing
	}

	public static void main(final String... args) {

		final WebMockObjectFactory factory = new WebMockObjectFactory();
		final MockServletContext context = factory.getMockServletContext();
		context.setInitParameter("debug", "true");
		context.setInitParameter("statsEnabled", "true");
		final ServletTestModule module = new ServletTestModule(factory);
		module.addFilter(new CompressingFilter(), true);
		module.setDoChain(true);

		final Random r = new Random(0xDEADBEEF);
		final String[] data = new String[200];
		for (int i = 0; i < data.length; i++) {
			final byte[] bytes = new byte[50];
			r.nextBytes(bytes);
			data[i] = new String(bytes);
		}

		module.setServlet(new HttpServlet() {
			@Override			
			public void doGet(final HttpServletRequest request,
			                  final HttpServletResponse response) throws IOException {
				final PrintWriter writer = response.getWriter();
				for (final String string : data) {
					writer.print(string);
				}
			}
		});
		final MockHttpServletRequest request = factory.getMockRequest();
		request.addHeader("Accept-Encoding", "gzip");

		for (int i = 0; i < 1000; i++) {
			module.doGet();
		}

	}


}
