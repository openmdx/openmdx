Please refer to the javadoc for CompressingFilter for installation and usage information; see the file docs/index.html.
