package bitronix.tm;

                                    public final class Version {
                                        public static String getVersion() {
                                            return "2.1.3";
                                        }
                                    }