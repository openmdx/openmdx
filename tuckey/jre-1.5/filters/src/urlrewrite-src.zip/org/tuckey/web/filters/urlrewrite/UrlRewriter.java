/**
 * Copyright (c) 2005, Paul Tuckey
 * All rights reserved.
 *
 * Each copy or derived work must preserve the copyright notice and this
 * notice unmodified.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
package org.tuckey.web.filters.urlrewrite;

import org.tuckey.web.filters.urlrewrite.utils.Log;
import org.tuckey.web.filters.urlrewrite.utils.StringUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;

/**
 * The main rewriter.
 *
 * @author Paul Tuckey
 * @version $Revision: 1.15 $ $Date: 2005/12/07 10:27:06 $
 *          <p/>
 *          <p/>
 *          <p/>   todo: It seems you need to hardcode the context path in your redirect rules.
 *          > Would be nice if a string such as "${context}" were interpolated, or any
 *          > paths not starting with a "/" were considered to be context-relative.
 */
public class UrlRewriter {

    private static Log log = Log.getLog(UrlRewriter.class);

    /**
     * The conf for this filter.
     */
    private Conf conf;

    public UrlRewriter(Conf conf) {
        this.conf = conf;
    }


    /**
     * The main method called for each request that this filter is mapped for.
     *
     * @return returns true when request has been handled by url rewriter false when
     */
    public RewrittenUrl processRequest(final HttpServletRequest hsRequest, final HttpServletResponse hsResponse)
            throws IOException, ServletException {

        String originalUrl = StringUtils.trim(hsRequest.getRequestURI());

        if (log.isDebugEnabled()) {
            log.debug("processing request for " + originalUrl);
        }

        if (originalUrl == null) {
            // for some reason the engine is not giving us the url
            // this isn't good
            log.debug("unable to fetch request uri from request.  This shouldn't happen, it may indicate that " +
                    "the web application server has a bug or that the request was not pased correctly.");
            return null;
        }

        // addition as suggested by Connor Barry
        try {
            originalUrl = URLDecoder.decode(originalUrl, "utf-8");
            if (log.isDebugEnabled()) {
                log.debug("after utf-8 decoding " + originalUrl);
            }
        } catch (java.io.UnsupportedEncodingException e) {
            log.warn("the jvm doesn't seem to support decoding utf-8, matches may not occur correctly.");
            return null;
        }
        // end addition

        // todo: further investigate ??? check for context path and remove if it's there ???
        String contextPath = hsRequest.getContextPath();
        if (contextPath != null && originalUrl.startsWith(contextPath)) {
            log.debug("context stripped");
            originalUrl = originalUrl.substring(contextPath.length());
        }

        // add the query string on uri (note, some web app containers to this)
        if (originalUrl.indexOf("?") == -1) {
            String query = hsRequest.getQueryString();
            if (query != null) {
                query = query.trim();
                if (query.length() > 0) {
                    originalUrl = originalUrl + "?" + query;
                }
            }
        }
        if (log.isDebugEnabled()) {
            log.debug("url " + originalUrl);
        }


        if (!conf.isOk()) {
            // when conf cannot be loaded for some sort of error
            // continue as normal without looking at the non-existent rules
            log.debug("configuration is not ok.  not rewriting request.");
            return null;
        }

        final List rules = conf.getRules();
        if (rules.size() == 0) {
            // no rules defined
            log.debug("there are no rules setup.  not rewriting request.");
            return null;
        }

        // attempt to match the rules
        String finalToUrl = originalUrl;
        RewrittenUrl finalRewrittenRequest = null;
        for (int i = 0; i < rules.size(); i++) {
            final Rule rule = (Rule) rules.get(i);
            final RewrittenUrl rewrittenUrl = rule.execute(finalToUrl, hsRequest, hsResponse);
            if (rewrittenUrl != null) {
                log.trace("got a rewritten url");
                finalRewrittenRequest = rewrittenUrl;
                finalToUrl = rewrittenUrl.getTarget();
                if (rule.isLast()) {
                    log.debug("rule is last");
                    // there can be no more matches on this request
                    break;
                }
            }
        }
        return finalRewrittenRequest;
    }

    public Conf getConf() {
        return conf;
    }

    /**
     * Handles rewriting urls in jsp's etc, i.e. response.encodeURL() is overriden in the response wrapper.
     *
     * @param hsResponse
     * @param hsRequest
     * @param encodeUrlHasBeenRun if encodeUrl has already been run on the originalOutboundUrl speficy this to be true
     * @param outboundUrl
     * @return
     * @see UrlRewriteWrappedResponse
     */
    protected RewrittenOutboundUrl processEncodeURL(HttpServletResponse hsResponse, HttpServletRequest hsRequest,
                                                    boolean encodeUrlHasBeenRun, String outboundUrl) {

        if (log.isDebugEnabled()) {
            log.debug("processing outbound url for " + outboundUrl);
        }

        if (outboundUrl == null) {
            // this probably means encode called with no url
            return new RewrittenOutboundUrl(outboundUrl, true);
        }

        // attempt to match the rules
        boolean finalEncodeOutboundUrl = true;
        String finalToUrl = outboundUrl;
        final List outboundRules = conf.getOutboundRules();
        for (int i = 0; i < outboundRules.size(); i++) {
            final OutboundRule outboundRule = (OutboundRule) outboundRules.get(i);
            if (!encodeUrlHasBeenRun && outboundRule.isEncodeFirst()) {
                continue;
            }
            if (encodeUrlHasBeenRun && !outboundRule.isEncodeFirst()) {
                continue;
            }
            final RewrittenOutboundUrl rewrittenUrl = outboundRule.execute(outboundUrl, hsRequest, hsResponse);
            if (rewrittenUrl != null) {
                // means this rule has matched
                if (log.isDebugEnabled()) {
                    log.debug("\"" + outboundRule.getDisplayName() + "\" matched");
                }
                finalToUrl = rewrittenUrl.getTarget();
                finalEncodeOutboundUrl = rewrittenUrl.isEncode();
                if (outboundRule.isLast()) {
                    log.debug("rule is last");
                    // there can be no more matches on this request
                    break;
                }
            }
        }
        return new RewrittenOutboundUrl(finalToUrl, finalEncodeOutboundUrl);
    }

    /**
     * Destory the rewriter gracefully.
     */
    public void destroy() {
        conf.destroy();
    }
}
