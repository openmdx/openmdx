/**
 * Copyright (c) 2005, Paul Tuckey
 * All rights reserved.
 *
 * Each copy or derived work must preserve the copyright notice and this
 * notice unmodified.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
package org.tuckey.web.filters.urlrewrite;

import org.tuckey.web.filters.urlrewrite.utils.Log;
import org.tuckey.web.filters.urlrewrite.utils.NumberUtils;
import org.tuckey.web.filters.urlrewrite.utils.StringUtils;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Date;

/**
 * Based on the popular and very useful mod_rewrite for apache, UrlRewriteFilter is a Java Web Filter for any J2EE
 * compliant web application server (such as Resin or Tomcat), which allows you to rewrite URLs before they get to your
 * code. It is a very powerful tool just like Apache's mod_rewrite.
 * <p/>
 * The main things it is used for are:
 * <p/>
 * <ul>
 * <li>URL Tidyness - keep URLs tidy irrespective of the underlying technology (JSPs, servlets, struts etc).</li>
 * <li>Browser Detection - Allows you to rewrite URLs based on request HTTP headers (such as "user-agent").</li>
 * <li>Date based rewriting - Allows you to forward or redirect to other URL's based on the date/time.</li>
 * </ul>
 * UrlRewriteFilter uses an xml file, called urlrewrite.xml (lives in the WEB-INF directory), for configuration. Most
 * parameters can be Perl5 style Regular Expressions. This makes it very powerful indeed.
 * <p/>
 * Special thanks to all those who gave patches/feedback especially Vineet Kumar.
 * <p/>
 * Thanks also to Ralf S. Engelschall (www.engelschall.com) the inventor of mod_rewrite
 * <p/>
 * <p/>
 * <p/>
 * todo: ability to test new conf without having to reload, via status page
 * todo: ability to have no from, just conditions matches
 * todo: user in role throw 403 if no match?
 * todo: ability to set default-to-type on <urlrewrite> level of conf file for conf files full of redirects
 * todo: allow condition matching on get-param or post-param as well as just parameter
 * todo: store list of robots and hide jsessionid when a robot also have condition
 * todo: allow mounting of packages from /xxxyyy/aaa.gif to org.tuckey.xxx.static."aaa.gif" http://wiki.opensymphony.com/pages/viewpage.action?pageId=4476
 * todo: think about a simple matching mode (ruletype wildcard) eg,
 * http://blah.com/some_context/dir/a-file.jsp;jsess=asasdsdas?someid=1#godown
 * The regexps etc should match on
 * ie,
 * <condition type="param" name="someid">1</condition>
 * <from>/dir/*.jsp</from>
 * <to>/anotherdir/$1.jsp</to>
 * or for regexp
 * <rule type="regexp">
 * <condition type="param" name="someid">1</condition>
 * <from>/dir/[a-z]-[a-z].jsp</from>
 * <to>/anotherdir/$1-$2.jsp</to>
 * </rule>
 * <p/>
 * todo: <on-startup><run </on-startup> <on-shutdown> <run </on-shutdown> will conflict with run in a rule init?
 * todo: handle exceptions, condition exception regexp match name
 * <p/>
 * todo: instanceof in urlrewrite filter conditions
 * <p/>
 * todo: When initially hitting my inventory page the links are in the format:
 * http://houston.freewaytrucks.com/fmi/xsl/browserecord-grid-flash.xsl;jsessionid=10876ED05390E6D24235ACC70ABCF977?-lay=Web+Inventory&-recid=11891&-find=-find
 * Could I write a rule using UrlRewrite that removes ;jsessionid=xxxxx�?
 * RewriteRule ^(/.*);jsessionid=.*$ $1
 * <p/>
 * todo: http://dtddoc.sourceforge.net/documentation.html
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * ---------- Forwarded message ----------
 * From: "Nestel, Frank IZ/HZA-IOL"
 * To: "Paul Tuckey" <paul@tuckey.org>
 * Date: Mon, 11 Jul 2005 10:56:38 +0200
 * Subject: RE: UrlRewriteFilter
 * Hello,
 * <p/>
 * UrlRewriteFilter still runs great for us, but I've
 * three feature remarks, which I though I'd implement
 * myself, but just don't have time to.
 * <p/>
 * 1. A target to-type "skip", i.e. skip the following
 * (i.e. remaining) rules. This would be an implementation
 * of a no-op filter and seems different of the "null" target.
 * The to-type="skip" actually would not need a target,
 * and one might consider making it "last='true'" on default.
 * <p/>
 * I'm here in the situation, that I have a bunch of complex
 * rules and just want to skip these for certain client IP's
 * and do not want to have the hassle with a complex
 * default expressions.
 * <p/>
 * 2. A randomized condition, i.e. a condition which is
 * true with a certain probability.
 * <p/>
 * 3. A round robin condition, i.e. a condition which is
 * true every n-th time.
 * <p/>
 * The latter two features would enable me to use UrlRewriteFilter
 * as a simple load distribution system between mirrored webservers.
 * <p/>
 * BTW I still saw some new Date().getTime() in the 2.4 Sourcecode.
 * Believe me System.currentTimeMillis() is so much faster and lighter.
 * <p/>
 * Maybe you have usage for this or time to implement it in
 * a future release? In the unlikely case I find time to write
 * Lines-Of-Code, then I'll send it to you.
 * <p/>
 * Kind regards,
 * Frank
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * <redirect><from>/for-moderators/login*</from><to>/for-partners/login.do</to></redirect>
 * <p/>
 * <redirect><from>/learner/results/*</from><to>/for-learners/results/login.do</to></redirect>
 * <p/>
 * <redirect><from>/providers/*</from><to>/www/for-providers/index.html</to></redirect>
 * <p/>
 * backrefs in sets
 * <p/>
 * request.roleId
 * <p/>
 * <p/>
 * <p/>
 * no error is trapped correctly and conf.isOk still return true???
 * <p/>
 * <p/>
 * better debugging of server name matcher
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * thommy
 * <t.ruess@catenate.com> to UrlRewrite
 * More options	  Oct 1
 * <p/>
 * Hi,
 * <p/>
 * I would like to have the session id appended to all urls I use
 * throughout an application.
 * <p/>
 * How can I write the sessionid into urls?
 * I tried out the following redirect with tuckey
 * <p/>
 * <rule>
 * <from>^(.*)$</from>
 * <to
 * encode="true">$1</to>
 * </rule>
 * but it didn't work
 * Is there some fixed constant like %{session} or similar that I could
 * use?
 * <p/>
 * Best regards,
 * Thomas
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * scspieker
 * to UrlRewrite
 * More options	  Oct 1
 * <p/>
 * Hello all,
 * I am converting a PHP application (which used the Apache ReWrite engine
 * - see rewrite rules below) over to Tomcat and I want to support the
 * previous URL syntax to keep existing real-world links and such working.
 * This site is uses 'channels' which contain behavior 'section' plug-ins
 * as possible end points (like image gallerys, links, downloads,
 * articles, etc) and possibly more channels.  Luckily the behavior
 * sections are unique and easy to handle.  However, the channels can be
 * nested and cause me some trouble.
 * <p/>
 * So here is an example of the original URL syntax:
 * 0 - www.example.com - Should open the home channel (same as #1 below)
 * 1 - www.example.com/channel - Opens the home channel
 * 2 - www.example.com/channel/flowers
 * 3 - www.example.com/channel/flowers/b.100.html
 * 4 - www.example.com/channel/flowers/b.100.r.200.html
 * 5 - www.example.com/channel/flowers/b.100.o.15.html
 * 6 - www.example.com/channel/flowers/mums
 * 7 - www.example.com/channel/flowers/mums/b.200.html
 * 8 - www.example.com/channel/flowers/mums/petals
 * ...
 * <p/>
 * Channel URI's (nested or otherwise) should always end with a /
 * So www.example.com/channel should always be rewritten as:
 * www.example.com/channel/ - same rule applies to #1, 2, 6 and 8 above in
 * the example.
 * <p/>
 * What I need are rules that will give me the following results:
 * 1 - URLs #1, 2, 6 and 8 above to have the same URL with a / appended.
 * 2 - URLs #3, 4, 5 and 7 to supply me with either the last 'channel'
 * name in the chain or a way to get the entire chain so that I can use a
 * Tokenizer to tear off just the end, and the behavior number (and record
 * or offset number if supplied as in #4, 5 and 7 above).
 * <p/>
 * So here is a couple of examples of rules that I have so far:
 * <rule>
 * <note>
 * This rule works great for URLs like:
 * www.example.com/channel/flowers/b.100.html
 * But this rule fails horribly with URLs like:
 * www.example.com/channel/flowers/mums/b.100.html
 * </note>
 * <from>^/channel/(.*)/b\.(.*).html$</from>
 * <to>/channel.jsp?rq_category=$1&amp;rq_behavior=$2</to>
 * </rule>
 * <rule>
 * <note>
 * This rule works great for URLs like:
 * www.example.com/channel/flowers/mums/b.100.html
 * But this rule fails horribly with URLs like:
 * www.example.com/channel/flowers/b.100.html
 * </note>
 * <from>^/channel/(.*)/(.*)/b\.(.*).html$</from>
 * <to>/channel.jsp?rq_category=$2&amp;rq_behavior=$3</to>
 * </rule>
 * These two work well if I only had the possibility of two nested
 * channels, however the site is dynamic in allowing more than one channel
 * to be nested - like in a linked list combination.  This chaning is
 * handled by the database relations, so all I need to know is the last
 * channel name from the URL and I can build the relations in code from
 * there.
 * <p/>
 * I have no idea how to make an expression that will change any URL that
 * DOES NOT end in .html to rewrite to whatever it is and append a '/' to
 * the end - for example: I need to change www.example.com/channel into
 * www.example.com/channel/  And more importantly, if the URL _DOES_
 * contain a '/' at the end, the it should be left alone...
 * <p/>
 * I also need to have: example.com/channel/flowers into
 * example.com/channel/flowers/
 * <p/>
 * <p/>
 * Here are the original Apache ReWrite rules used for the PHP version of
 * the site (I really don't know what to do with the application Type and
 * QSA values at the end - I don't think these translate or can be passed
 * using the URLReWrite filter AFAIK):
 * <p/>
 * RewriteRule ^/click(.*)/b\.(.*)\.r\.(.*)\.html
 * /click.html?rq_category=$1&rq_behavior=$2&c_regard=$3
 * [L,T=application/x-httpd-php]
 * RewriteRule ^/channel.html(.*) /channel.html$3
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/content.html(.*) /content.html$3
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/channel(.*)/b\.(.*)\.o\.(.*)\.r\.(.*)\.g\.(.*).html
 * /content.html?rq_category=$1&rq_behavior=$2&c_offset=$3&c_regard=$4&rq_location_id=$5
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/channel(.*)/b\.(.*)\.r\.(.*)\.g\.(.*).html
 * /content.html?rq_category=$1&rq_behavior=$2&c_regard=$3&rq_location_id=$4
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/channel(.*)/b\.(.*)\.o\.(.*)\.r\.(.*).html
 * /content.html?rq_category=$1&rq_behavior=$2&c_offset=$3&c_regard=$4
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/channel(.*)/b\.(.*)\.o\.(.*)\.g\.(.*).html
 * /content.html?rq_category=$1&rq_behavior=$2&c_offset=$3&rq_location_id=$4
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/channel(.*)/b\.(.*)\.o\.(.*).html
 * /content.html?rq_category=$1&rq_behavior=$2&c_offset=$3
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/channel(.*)/b\.(.*)\.r\.(.*)\.html
 * /content.html?rq_category=$1&rq_behavior=$2&c_regard=$3
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/channel(.*)/b\.(.*)\.g\.(.*)\.html
 * /content.html?rq_category=$1&rq_behavior=$2&rq_location_id=$3
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/channel(.*)/b\.(.*)\.html
 * /content.html?rq_category=$1&rq_behavior=$2
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/channel(.*)/a\.(.*)\.g\.(.*)\.html
 * /channel.html?rq_category=$1&rq_cmd=$2&rq_location_id=$3
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/channel(.*)/a\.(.*)\.html
 * /channel.html?rq_category=$1&rq_cmd=$2
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/channel(.*)/g\.(.*)\.html
 * /channel.html?rq_category=$1&rq_location_id=$2
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/bio/(.*) /profile.html?rq_ln=$1
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/channel(.*) /channel.html?rq_category=$1
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/contribute(.*)/b\.(.*)\.r\.(.*)\.g\.(.*).html
 * /contribute.html?rq_category=$1&rq_behavior=$2&c_regard=$3&c_location_id=$4
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/contribute(.*)/b\.(.*)\.r\.(.*)\.i\.(.*).html
 * /contribute.html?rq_category=$1&rq_behavior=$2&c_regard=$3&c_uniqid=$4
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/contribute(.*)/b\.(.*)\.r\.(.*).html
 * /contribute.html?rq_category=$1&rq_behavior=$2&c_regard=$3
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/contribute(.*)/b\.(.*)\.g\.(.*)\.html
 * /contribute.html?rq_category=$1&rq_behavior=$2&rq_location_id=$3
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * RewriteRule ^/contribute(.*)/b\.(.*).html
 * /contribute.html?rq_category=$1&rq_behavior=$2
 * [L,T=application/x-httpd-php,QSA=%{QUERY_STRING}]
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * pbirchmeier to UrlRewrite
 * More options	  Oct 7
 * <p/>
 * Hi all
 * <p/>
 * I'm using OpenCms on a ISP, so it is difficult for me to change the
 * httpd.conf in order to rewrite urls. So UrlRewriteFilter came in the
 * right point in time, because thanks to this tool i'm able to setup the
 * url rewriting mechanism in tomcat...
 * <p/>
 * thanks for that great tool!
 * <p/>
 * but now to the point:
 * Unfortunately OpenCms in its actual version 6.0.0 shows strange
 * behaviors when using together with UrlRewriteFilter. On the first
 * sight, everything seems to work properly. Then, on the OpenCms
 * workplace, you open a file in an editor and try to close it - you'll
 * get a blank page! I tested this problem with several
 * UrlRewriteFilter-configurations and finally concluded, that it must be
 * a general problem. I wrote a similiar, in functionality strongly
 * reduced rewrite tool and it worked. So I rewatched the source code and
 * replaced all response-wrapper references by the original response
 * references, and voila: full success...
 * (ok outbound-rules don't work anymore by this approach)
 * <p/>
 * in details:
 * in the UrlRewriteFilter class, in the doFilter method, i replaced all
 * request objects urlRewriteWrappedResponse by hsResponse.
 * <p/>
 * don't ask me about the reason... i have no idea. in the OpenCms source
 * code, i found several sendForward-calls, which must have caused the
 * problems.
 * <p/>
 * <p/>
 * now my question to the inventor of this tool:
 * Do you know that phenomenon? and would a configuration property to
 * optionally switch off the UrlRewriteWrappedResponse-functionality (or
 * with other words the outbounds-rules-functionality) make sense to be
 * integrated?
 * <p/>
 * see: http://mail.opencms.org/pipermail/opencms-dev/2005q4/019939.html
 * <p/>
 * thanks for any comments.. and hints
 * <p/>
 * kind regards,
 * Peter Birchmeier
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * treeder to UrlRewrite
 * More options	  Oct 10
 * <p/>
 * Lets say you setup a filter like so:
 * <p/>
 * <from>^/something/([a-z]+)/</from>
 * <to type="forward">/index.jsp?someting=$1</to>
 * <p/>
 * But now any relative image, css or script will not work because it will
 * try to retrieve them from the /something/... path.  I know I can
 * specify "/images/abc.gif" to make it start from root, but what if you
 * end up putting the application in a context like www.xyz.com/myapp/ ,
 * then the absolute path no longer works.
 * <p/>
 * I know there are ways to work through this, but just wondering if
 * someone has a "works for all cases" solution.
 * <p/>
 * <p/>
 * <p/>
 * Gast, Thorsten IZ/HZA-IOL
 * gasttor to ptuckey
 * More options	  Oct 13
 * Hello Paul,
 * <p/>
 * I ran into some problems using urlrewrite, that were caused by the
 * decoding of the
 * original url in UrlRewriter.
 * <p/>
 * originalUrl = URLDecoder.decode(originalUrl, "utf-8"); // line 99 in
 * version 2.5.2
 * <p/>
 * Is this line mandatory? If not, what do you think of making this feature
 * switchable.
 * e.g. for the complete web-application or even for every rule.
 * <p/>
 * Regards
 * <p/>
 * Thorsten
 * <p/>
 * <p/>
 * take off default on encode for to element
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * Nathan Egge
 * <nathanegge to paul
 * More options	  Oct 22
 * Hey Paul,
 * <p/>
 * Just wanted to let you know that I got the debugging
 * working, and I was able to figure out my rewrite
 * rules.  For some reason your code stops when it finds
 * the first rule it matches.  So I simply match my
 * /images directory first, and then map it to /images
 * before my later mappings.
 * <p/>
 * Thanks for all your help.
 * <p/>
 * Nathan
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * jaeschke
 * to UrlRewrite
 * More options	  Nov 1
 * <p/>
 * Hello,
 * <p/>
 * I would appreciate some help with the following problem: I have some
 * rules like this one
 * <p/>
 * <rule>
 * <from>/+colors/+([^/]+?)(\?(.*))?$</from>
 * <to>/ResourceHandler?page=colors&amp;requColors=$1&amp;$3</to>
 * </rule>
 * <p/>
 * If an URL like "/colors/black%26white?myParam=foo" is requested, the
 * URL is rewritten to
 * "/ResourceHandler?page=colors&requColors=black&white&myParam=foo"
 * which causes the parameter requWord to be "black" instead of being
 * "black&white".
 * <p/>
 * Of course this could be solved with double URL-encoding - the URL
 * "/word/black%2526white?myParam=foo" does what I want. But that's not
 * nice for several reasons.
 * <p/>
 * Is it possible to force URLRewriteFilter to (re-)encode matched
 * variables when
 * they're appended in the <to> rule?
 * <p/>
 * <p/>
 * <p/>
 * Thanks, Robert
 * <p/>
 * <p/>
 * <p/>
 * <p/>
 * dependencies shoul be in src zip , servlet, ant
 *
 * @author Paul Tuckey
 * @version $Revision: 1.24 $ $Date: 2005/12/07 10:27:05 $
 */
public final class UrlRewriteFilter implements Filter {

    private static Log log = Log.getLog(UrlRewriteFilter.class);

    // next line is replaced by ant on compile
    public static final String VERSION = "2.6.0 build 5728";

    public static final String DEFAULT_WEB_CONF_PATH = "/WEB-INF/urlrewrite.xml";

    /**
     * The conf for this filter.
     */
    private UrlRewriter urlRewriter = null;

    /**
     * A user defined setting that can enable conf reloading.
     */
    private boolean confReloadCheckEnabled = false;

    /**
     * A user defined setting that says how often to check the conf has changed.
     */
    private int confReloadCheckInterval = 0;

    /**
     * The last time that the conf file was loaded.
     */
    private long confLastLoad = 0;
    private Conf confLastLoaded = null;
    private long confReloadLastCheck = 30;

    /**
     * Flag to make sure we don't bog the filter down during heavy load.
     */
    private boolean confReloadInProgress = false;

    private boolean statusEnabled = true;
    private String statusPath = "/rewrite-status";

    private ServerNameMatcher statusServerNameMatcher;
    private static final String DEFAULT_STATUS_ENABLED_ON_HOSTS = "localhost, local, 127.0.0.1";


    /**
     *
     */
    private ServletContext context = null;

    /**
     * Init is called automatically by the application server when it creates this filter.
     *
     * @param filterConfig The config of the filter
     */
    public void init(final FilterConfig filterConfig) {

        log.debug("filter init called");
        if (filterConfig == null) {
            log.error("unable to init filter as filter config is null");
            return;
        }

        log.debug("init: calling destroy just in case we are being re-inited uncleanly");
        destroyActual();

        context = filterConfig.getServletContext();
        if (context == null) {
            log.error("unable to init as servlet context is null");
            return;
        }

        // set the conf of the logger to make sure we get the messages in context log
        Log.setConfiguration(filterConfig);

        log.debug("loaded into servlet context: " + context.getServletContextName());

        // get init paramerers from context web.xml file
        String confReloadCheckIntervalStr = filterConfig.getInitParameter("confReloadCheckInterval");
        String statusPathConf = filterConfig.getInitParameter("statusPath");
        String statusEnabledConf = filterConfig.getInitParameter("statusEnabled");
        String statusEnabledOnHosts = filterConfig.getInitParameter("statusEnabledOnHosts");

        // confReloadCheckInterval (default to null)
        if (confReloadCheckIntervalStr != null && !"".equals(confReloadCheckIntervalStr)) {
            // convert to millis
            confReloadCheckInterval = 1000 * NumberUtils.stringToInt(confReloadCheckIntervalStr);
            confReloadCheckEnabled = true;
            if (confReloadCheckInterval == 0) {
                log.info("reload check performed each request");
            } else {
                log.info("reload check set to " + confReloadCheckInterval / 1000 + "s");
            }
        } else {
            confReloadCheckEnabled = false;
        }

        // status enabled (default true)
        if (statusEnabledConf != null && !"".equals(statusEnabledConf)) {
            log.debug("statusEnabledConf set to " + statusEnabledConf);
            statusEnabled = "true".equals(statusEnabledConf.toLowerCase());
        }
        if (statusEnabled) {
            // status path (default /rewrite-status)
            if (statusPathConf != null && !"".equals(statusPathConf)) {
                statusPath = statusPathConf.trim();
                log.info("status display enabled, path set to " + statusPath);
            }
        } else {
            log.info("status display disabled");
        }

        if (StringUtils.isBlank(statusEnabledOnHosts)) statusEnabledOnHosts = DEFAULT_STATUS_ENABLED_ON_HOSTS;
        else
            log.debug("statusEnabledOnHosts set to " + statusEnabledOnHosts);
        statusServerNameMatcher = new ServerNameMatcher(statusEnabledOnHosts);

        loadConf();
    }

    private void loadConf() {
        InputStream inputStream = context.getResourceAsStream(DEFAULT_WEB_CONF_PATH);
        if (inputStream == null) {
            log.error("unable to find urlrewrite conf file at " + DEFAULT_WEB_CONF_PATH);
            // set the writer back to null
            if (urlRewriter != null) {
                log.error("unloading existing conf");
                urlRewriter = null;
            }

        } else {
            Conf conf = new Conf(context, inputStream, "urlrewrite.xml");
            if (log.isDebugEnabled()) {
                if (conf.getRules() != null) {
                    log.debug("inited with " + conf.getRules().size() + " rules");
                }
                log.debug("conf is " + (conf.isOk() ? "ok" : "NOT ok"));
            }
            confLastLoaded = conf;
            if (conf.isOk()) {
                urlRewriter = new UrlRewriter(conf);
                log.info("loaded (conf ok)");

            } else {
                log.error("Conf failed to load");
                log.error("unloading existing conf");
                urlRewriter = null;
            }
        }
    }

    /**
     * Destroy is called by the application server when it unloads this filter.
     */
    public void destroy() {
        log.info("destroy called");
        destroyActual();
    }

    public void destroyActual() {
        if (urlRewriter != null) {
            urlRewriter.destroy();
            urlRewriter = null;
        }
        context = null;
        confLastLoad = 0;
        confReloadCheckEnabled = false;
        confReloadCheckInterval = 0;
        confReloadInProgress = false;
    }

    /**
     * The main method called for each request that this filter is mapped for.
     *
     * @param request
     * @param response
     * @param chain
     * @throws IOException
     * @throws ServletException
     */
    public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain)
            throws IOException, ServletException {

        // check to see if the conf needs reloading
        long now = System.currentTimeMillis();
        if (confReloadCheckEnabled && !confReloadInProgress &&
                (now - confReloadCheckInterval) > confReloadLastCheck) {
            confReloadInProgress = true;
            confReloadLastCheck = now;

            log.debug("starting conf reload check");
            long confFileCurrentTime = getConfFileLastModified();
            if (confLastLoad < confFileCurrentTime) {
                // reload conf
                confLastLoad = System.currentTimeMillis();
                log.info("conf file modified since last load, reloading");
                loadConf();
            } else {
                log.debug("conf is not modified");
            }

            confReloadInProgress = false;
        }

        final HttpServletRequest hsRequest = (HttpServletRequest) request;
        final HttpServletResponse hsResponse = (HttpServletResponse) response;
        UrlRewriteWrappedResponse urlRewriteWrappedResponse = new UrlRewriteWrappedResponse(hsResponse, hsRequest,
                urlRewriter);

        // check for status request
        if (statusEnabled && statusServerNameMatcher.isMatch(request.getServerName())) {
            String uri = hsRequest.getRequestURI();
            if (log.isDebugEnabled()) {
                log.debug("checking for status path on " + uri);
            }
            String contextPath = hsRequest.getContextPath();
            if (uri != null && uri.startsWith(contextPath + statusPath)) {
                showStatus(hsRequest, urlRewriteWrappedResponse);
                return;
            }
        }

        boolean requestRewritten = false;
        if (urlRewriter != null) {

            // process the request
            RewrittenUrl rewrittenUrl = urlRewriter.processRequest(hsRequest, urlRewriteWrappedResponse);
            if (rewrittenUrl != null) {
                requestRewritten = rewrittenUrl.doRewrite(hsRequest, urlRewriteWrappedResponse, chain);
            }
        } else {
            if (log.isDebugEnabled()) {
                log.debug("urlRewriter engine not loaded ignoring request (could be a conf file problem)");
            }
        }

        // if no rewrite has taken place continue as normal
        if (!requestRewritten) {
            chain.doFilter(hsRequest, urlRewriteWrappedResponse);
        }
    }


    /**
     * Gets the last modified date of the conf file.
     *
     * @return time as a long
     */
    private long getConfFileLastModified() {
        File confFile = new File(context.getRealPath(DEFAULT_WEB_CONF_PATH));
        return confFile.lastModified();
    }


    /**
     * Show the status of the conf and the filter to the user.
     *
     * @param request
     * @param response
     * @throws java.io.IOException
     */
    private void showStatus(final HttpServletRequest request, final ServletResponse response)
            throws IOException {

        log.debug("showing status");

        Status status = new Status(confLastLoaded, this);
        status.displayStatusInContainer(request);

        response.setContentLength(status.getBuffer().length());

        final PrintWriter out = response.getWriter();
        out.write(status.getBuffer().toString());
        out.close();

    }

    public boolean isConfReloadCheckEnabled() {
        return confReloadCheckEnabled;
    }

    /**
     * The amount of seconds between reload checks.
     */
    public int getConfReloadCheckInterval() {
        return confReloadCheckInterval / 1000;
    }

    public Date getConfReloadLastCheck() {
        return new Date(confReloadLastCheck);
    }

    public boolean isStatusEnabled() {
        return statusEnabled;
    }

    public String getStatusPath() {
        return statusPath;
    }

    public boolean isLoaded() {
        return urlRewriter != null;
    }
}
