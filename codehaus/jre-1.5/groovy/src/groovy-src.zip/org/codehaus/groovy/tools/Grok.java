package org.codehaus.groovy.tools;

/**
 * This is a stub for the Groovy Doc tool
 * 
 * @author James Strachan
 * @version $Revision: 246 $
 */
public class Grok
{
    public static void main(String[] args)
    {
        
    }
}
