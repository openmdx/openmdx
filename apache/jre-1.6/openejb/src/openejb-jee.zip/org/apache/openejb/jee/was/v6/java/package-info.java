@javax.xml.bind.annotation.XmlSchema(namespace = "java.xmi")
package org.apache.openejb.jee.was.v6.java;
