@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.eclipse.org/emf/2002/Ecore")
package org.apache.openejb.jee.was.v6.ecore;
