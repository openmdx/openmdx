@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.omg.org/XMI")
package org.apache.openejb.jee.was.v6.xmi;
